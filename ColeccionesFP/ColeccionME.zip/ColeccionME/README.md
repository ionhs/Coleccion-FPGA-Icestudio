# Lista de componentes de ColeccionFP

### Puertas Lógicas

|            Componente             |                SVG                 |            Autor            |     Info      |
| :-------------------------------: | :--------------------------------: | :-------------------------: | :-----------: |
|  [AND](blocks/1-Puertas/and.ice)  | ![](blocks/1-Puertas/svg/and.svg)  | Jesús Arroyo, Juan González | Versión 1.0.1 |
|   [OR](blocks/1-Puertas/or.ice)   |  ![](blocks/1-Puertas/svg/or.svg)  | Jesús Arroyo, Juan González | Versión 1.0.1 |
|  [NOT](blocks/1-Puertas/not.ice)  | ![](blocks/1-Puertas/svg/not.svg)  | Jesús Arroyo, Juan González | Versión 1.0.3 |
| [NAND](blocks/1-Puertas/nand.ice) | ![](blocks/1-Puertas/svg/nand.svg) | Jesús Arroyo, Juan González | Versión 1.0.1 |
|  [NOR](blocks/1-Puertas/nor.ice)  | ![](blocks/1-Puertas/svg/nor.svg)  | Jesús Arroyo, Juan González | Versión 1.0.1 |
|  [XOR](blocks/1-Puertas/xor.ice)  | ![](blocks/1-Puertas/svg/xor.svg)  | Jesús Arroyo, Juan González | Versión 1.0.1 |
| [XNOR](blocks/1-Puertas/xnor.ice) | ![](blocks/1-Puertas/svg/xnor.svg) | Jesús Arroyo, Juan González | Versión 1.0.1 |

### Circuitos Combinacionales y Aritméticos

| Componente  | Download | SVG  |       Autor       |                             Info                             |
| :---------: | :------: | :--: | :---------------: | :----------------------------------------------------------: |
|   cod-2-1   |          |      |                   |                                                              |
|   cod-4-2   |          |      |                   |                                                              |
| cod-4-2-bus |          |      |                   |                                                              |
| cod-8-3-bus |          |      |                   |                                                              |
|     ALU     |          |      | María Isabel Díaz | https://github.com/minicatsCB/FPGA  https://twitter.com/Totodilesi/status/1061605017445117954 |

### Circuitos Secuenciales

| Componente | Download | SVG  | Autor | Info |
| :--------: | :------: | :--: | :---: | :--: |
|            |          |      |       |      |
|            |          |      |       |      |
|            |          |      |       |      |

### Microcontroladores

| Componente | Download | SVG  | Autor | Info |
| :--------: | :------: | :--: | :---: | :--: |
|            |          |      |       |      |
|            |          |      |       |      |
|            |          |      |       |      |

### Periféricos

| Componente | Download | SVG  | Autor |                             Info                             |
| :--------: | :------: | :--: | :---: | :----------------------------------------------------------: |
|            |          |      |       |                                                              |
|   Sonido   |          |      |       | https://groups.google.com/forum/#!msg/fpga-wars-explorando-el-lado-libre/5b0ULNjZZKA/QcV-lF0bCAAJ |
| Motor PaP  |          |      |       | https://github.com/jospicant/IceStudio/tree/master/Ice40/Robot/Modules   https://github.com/Obijuan/escornabot-fpga/tree/master/Escornabot-collection |

